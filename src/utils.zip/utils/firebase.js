
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import { getAuth, signInWithPopup, GoogleAuthProvider } from "firebase/auth";


const config = {
  apiKey: "AIzaSyBIIZwur67yPXew3JQgqPklO1R2jx4dWZ4",
  authDomain: "ticktick-a750c.firebaseapp.com",
  databaseURL: "https://ticktick-a750c-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "ticktick-a750c",
  storageBucket: "ticktick-a750c.appspot.com",
  messagingSenderId: "938712980760",
  appId: "1:938712980760:web:e86215e3e1339ac224d26d",
  measurementId: "G-8S2RMDBVHE"
};

  // Initialize Firebase
const app = firebase.initializeApp(config);
export const firestore = firebase.firestore();



export const convertCollectionMap = (collection) => {
  const transforCollection = collection.docs.map(x =>  {  return x.data()} );
  return transforCollection
}




export const provider = new GoogleAuthProvider();

export const auth = getAuth();


export const signGoogle = () => {
  signInWithPopup(auth, provider) 
.then((result) => {
  // This gives you a Google Access Token. You can use it to access the Google API.
  const credential = GoogleAuthProvider.credentialFromResult(result);
  const token = credential.accessToken;
  // The signed-in user info.
  const user = result.user;
 console.log(user);
  
  // ...
}).catch((error) => {
  // Handle Errors here.
  const errorCode = error.code;
  const errorMessage = error.message;
  // The email of the user's account used.
  const email = error.email;
  // The AuthCredential type that was used.
  const credential = GoogleAuthProvider.credentialFromError(error);
  // ...
})

}










export default app;
